package ir.game.haftkhabisvip.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import ir.game.haftkhabisvip.model.ClientIntent
import ir.game.haftkhabisvip.model.GameState
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * شبکه‌ی بازی روی وای‌فای / هات‌اسپات (سوکت TCP ساده، بدون نیاز به سرویس‌های گوگل).
 * میزبان: ServerSocket روی پورت ثابت + پاسخ به جستجوی UDP
 * کلاینت: اتصال به آی‌پی میزبان (گیت‌وی هات‌اسپات، جستجوی خودکار یا دستی)
 */
class LanNetworkManager(context: Context, private val listener: Listener) {

    interface Listener {
        fun onClientJoined(clientId: String, name: String)
        fun onClientLeft(clientId: String)
        fun onIntent(clientId: String, intent: ClientIntent)
        fun onJoined(myId: String)
        fun onLobby(names: List<String>)
        fun onState(state: GameState)
        fun onDisconnectedFromHost()
        fun onError(message: String)
        fun onHostFound(ip: String, name: String)
        fun onDiscoveryFinished()
    }

    companion object {
        const val TCP_PORT = 47821
        const val UDP_PORT = 47822
        private const val DISCOVER_MSG = "HK_DISCOVER"
        private const val HOST_MSG = "HK_HOST:"
        private const val MAX_CLIENTS = 6
        private const val SEP = '\u001F'
    }

    private class ClientConn(val id: String, val name: String, val socket: Socket, val writer: BufferedWriter)

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val json = Json { ignoreUnknownKeys = true }
    private val pool: ExecutorService = Executors.newCachedThreadPool()
    private val sender: ExecutorService = Executors.newSingleThreadExecutor()

    private val clients = ConcurrentHashMap<String, ClientConn>()
    private val idCounter = AtomicInteger(0)
    @Volatile private var hostRunning = false
    @Volatile var acceptingJoins = true
    private var serverSocket: ServerSocket? = null
    private var discoveryResponder: DatagramSocket? = null

    @Volatile private var clientSocket: Socket? = null
    @Volatile private var clientWriter: BufferedWriter? = null
    @Volatile private var clientToken: Any? = null

    private fun post(block: () -> Unit) {
        main.post { block() }
    }

    private fun clean(name: String): String =
        name.replace(Regex("[\\r\\n\\u001F]"), " ").trim().take(20).ifEmpty { "بازیکن" }

    // ------------------------------------------------------------------ host

    fun startHost(hostName: String) {
        stopHost()
        hostRunning = true
        acceptingJoins = true
        val safeName = clean(hostName)

        pool.execute {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(TCP_PORT))
                serverSocket = ss
                while (hostRunning) {
                    val s = ss.accept()
                    pool.execute { handleClient(s) }
                }
            } catch (e: Exception) {
                if (hostRunning) post { listener.onError("راه‌اندازی میزبان ناموفق بود: ${e.message}") }
            }
        }
        pool.execute { runDiscoveryResponder(safeName) }
    }

    private fun runDiscoveryResponder(hostName: String) {
        try {
            val ds = DatagramSocket(null)
            ds.reuseAddress = true
            ds.bind(InetSocketAddress(UDP_PORT))
            discoveryResponder = ds
            val buf = ByteArray(256)
            while (hostRunning) {
                val p = DatagramPacket(buf, buf.size)
                ds.receive(p)
                val msg = String(p.data, 0, p.length, Charsets.UTF_8)
                if (msg == DISCOVER_MSG) {
                    val reply = (HOST_MSG + hostName).toByteArray(Charsets.UTF_8)
                    ds.send(DatagramPacket(reply, reply.size, p.address, p.port))
                }
            }
        } catch (e: Exception) {
            // سوکت بسته شد یا پورت در دسترس نبود؛ اتصال مستقیم با آی‌پی همچنان کار می‌کند
        }
    }

    private fun handleClient(s: Socket) {
        var id: String? = null
        try {
            s.tcpNoDelay = true
            val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
            val writer = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))

            s.soTimeout = 5000
            val hello = reader.readLine()
            s.soTimeout = 0
            if (hello == null || !hello.startsWith("HELLO:")) {
                s.close()
                return
            }
            if (!acceptingJoins || clients.size >= MAX_CLIENTS) {
                writer.write("FULL:")
                writer.newLine()
                writer.flush()
                s.close()
                return
            }
            val name = clean(hello.removePrefix("HELLO:"))
            val newId = "P${idCounter.incrementAndGet()}"
            id = newId
            val conn = ClientConn(newId, name, s, writer)
            clients[newId] = conn
            send(conn, "WELCOME:$newId")
            post { listener.onClientJoined(newId, name) }

            while (true) {
                val line = reader.readLine() ?: break
                if (line.startsWith("INTENT:")) {
                    val intent = json.decodeFromString(ClientIntent.serializer(), line.removePrefix("INTENT:"))
                    post { listener.onIntent(newId, intent) }
                }
            }
        } catch (e: Exception) {
            // اتصال قطع شد
        } finally {
            val myId = id
            if (myId != null && clients.remove(myId) != null) {
                post { listener.onClientLeft(myId) }
            }
            try { s.close() } catch (e: Exception) { }
        }
    }

    private fun send(conn: ClientConn, line: String) {
        sender.execute {
            try {
                synchronized(conn.writer) {
                    conn.writer.write(line)
                    conn.writer.newLine()
                    conn.writer.flush()
                }
            } catch (e: Exception) {
                try { conn.socket.close() } catch (e2: Exception) { }
            }
        }
    }

    private fun broadcast(line: String) {
        clients.values.forEach { send(it, line) }
    }

    fun broadcastState(state: GameState) {
        if (clients.isEmpty()) return
        broadcast("STATE:" + json.encodeToString(GameState.serializer(), state))
    }

    fun broadcastLobby(names: List<String>) {
        if (clients.isEmpty()) return
        broadcast("LOBBY:" + names.joinToString(SEP.toString()))
    }

    fun stopHost() {
        hostRunning = false
        try { serverSocket?.close() } catch (e: Exception) { }
        serverSocket = null
        try { discoveryResponder?.close() } catch (e: Exception) { }
        discoveryResponder = null
        clients.values.forEach { try { it.socket.close() } catch (e: Exception) { } }
        clients.clear()
    }

    // ---------------------------------------------------------------- client

    fun connect(ip: String, name: String) {
        disconnect()
        val token = Any()
        clientToken = token
        pool.execute {
            var socket: Socket? = null
            var joined = false
            try {
                val wifi = wifiNetwork()
                val s: Socket = if (wifi != null) wifi.socketFactory.createSocket() else Socket()
                socket = s
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(ip, TCP_PORT), 4000)

                val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                val writer = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))
                writer.write("HELLO:" + clean(name))
                writer.newLine()
                writer.flush()

                s.soTimeout = 5000
                val first = reader.readLine()
                s.soTimeout = 0

                if (first == null) throw IOException("میزبان پاسخ نداد")
                if (first.startsWith("FULL")) {
                    if (clientToken === token) post { listener.onError("میز پر است یا بازی از قبل شروع شده.") }
                    return@execute
                }
                if (!first.startsWith("WELCOME:")) throw IOException("پاسخ نامعتبر")
                if (clientToken !== token) return@execute

                clientSocket = s
                clientWriter = writer
                joined = true
                val myId = first.removePrefix("WELCOME:")
                post { listener.onJoined(myId) }

                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.startsWith("STATE:")) {
                        val st = json.decodeFromString(GameState.serializer(), line.removePrefix("STATE:"))
                        post { listener.onState(st) }
                    } else if (line.startsWith("LOBBY:")) {
                        val names = line.removePrefix("LOBBY:").split(SEP).filter { it.isNotBlank() }
                        post { listener.onLobby(names) }
                    }
                }
                if (clientToken === token) post { listener.onDisconnectedFromHost() }
            } catch (e: Exception) {
                if (clientToken === token) {
                    if (joined) post { listener.onDisconnectedFromHost() }
                    else post { listener.onError("اتصال برقرار نشد. مطمئن شوید به هات‌اسپات میزبان وصل هستید و میزبان «ساخت میز» را زده است.") }
                }
            } finally {
                try { socket?.close() } catch (e: Exception) { }
            }
        }
    }

    fun sendIntent(intent: ClientIntent) {
        val w = clientWriter ?: return
        val line = "INTENT:" + json.encodeToString(ClientIntent.serializer(), intent)
        sender.execute {
            try {
                synchronized(w) {
                    w.write(line)
                    w.newLine()
                    w.flush()
                }
            } catch (e: Exception) {
                try { clientSocket?.close() } catch (e2: Exception) { }
            }
        }
    }

    fun disconnect() {
        clientToken = null
        try { clientSocket?.close() } catch (e: Exception) { }
        clientSocket = null
        clientWriter = null
    }

    // ------------------------------------------------------------- discovery

    fun discoverHosts(timeoutMs: Long = 3000) {
        pool.execute {
            var sock: DatagramSocket? = null
            try {
                val ds = DatagramSocket()
                sock = ds
                ds.broadcast = true
                ds.soTimeout = 400
                try { wifiNetwork()?.bindSocket(ds) } catch (e: Exception) { }

                val msg = DISCOVER_MSG.toByteArray(Charsets.UTF_8)
                val targets = mutableSetOf<InetAddress>()
                try { targets.add(InetAddress.getByName("255.255.255.255")) } catch (e: Exception) { }
                broadcastIp()?.let { try { targets.add(InetAddress.getByName(it)) } catch (e: Exception) { } }
                gatewayIp()?.let { try { targets.add(InetAddress.getByName(it)) } catch (e: Exception) { } }

                val end = System.currentTimeMillis() + timeoutMs
                var lastSend = 0L
                val buf = ByteArray(256)
                val seen = mutableSetOf<String>()
                while (System.currentTimeMillis() < end) {
                    val now = System.currentTimeMillis()
                    if (now - lastSend > 800) {
                        lastSend = now
                        for (t in targets) {
                            try { ds.send(DatagramPacket(msg, msg.size, t, UDP_PORT)) } catch (e: Exception) { }
                        }
                    }
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        ds.receive(p)
                        val text = String(p.data, 0, p.length, Charsets.UTF_8)
                        if (text.startsWith(HOST_MSG)) {
                            val ip = p.address.hostAddress ?: continue
                            if (seen.add(ip)) {
                                val hostName = text.removePrefix(HOST_MSG)
                                post { listener.onHostFound(ip, hostName) }
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                        // ادامه
                    }
                }
            } catch (e: Exception) {
                // نادیده
            } finally {
                try { sock?.close() } catch (e: Exception) { }
                post { listener.onDiscoveryFinished() }
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun intToIp(i: Int): String =
        "${i and 0xff}.${(i shr 8) and 0xff}.${(i shr 16) and 0xff}.${(i shr 24) and 0xff}"

    /** آی‌پی گوشی میزبانِ هات‌اسپات از دید کلاینت (گیت‌وی). */
    @Suppress("DEPRECATION")
    fun gatewayIp(): String? {
        return try {
            val wm = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return null
            val gw = wm.dhcpInfo?.gateway ?: 0
            if (gw != 0) intToIp(gw) else null
        } catch (e: Exception) {
            null
        }
    }

    @Suppress("DEPRECATION")
    private fun broadcastIp(): String? {
        return try {
            val wm = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return null
            val d = wm.dhcpInfo ?: return null
            if (d.netmask == 0 || d.ipAddress == 0) null
            else intToIp((d.ipAddress and d.netmask) or d.netmask.inv())
        } catch (e: Exception) {
            null
        }
    }

    /** آی‌پی‌های این گوشی (برای نمایش به دیگران وقتی میزبان هستیم). */
    fun localIpv4(): List<String> {
        val result = mutableListOf<String>()
        try {
            val ifaces = NetworkInterface.getNetworkInterfaces() ?: return result
            for (ni in Collections.list(ifaces)) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name ?: ""
                if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("tun") ||
                    n.startsWith("v4-") || n.startsWith("dummy")
                ) continue
                for (addr in Collections.list(ni.inetAddresses)) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress
                        if (ip != null) result.add(ip)
                    }
                }
            }
        } catch (e: Exception) {
        }
        return result
    }

    /** اگر گوشی اینترنت همراه هم دارد، ترافیک بازی باید حتماً از مسیر وای‌فای برود. */
    @Suppress("DEPRECATION")
    private fun wifiNetwork(): Network? {
        return try {
            val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.allNetworks.firstOrNull { n ->
                cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            }
        } catch (e: Exception) {
            null
        }
    }

    fun stopAll() {
        stopHost()
        disconnect()
    }

    fun shutdown() {
        stopAll()
        pool.shutdownNow()
        sender.shutdownNow()
    }
}
