package ir.game.haftkhabisvip.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.game.haftkhabisvip.audio.SoundEffects
import ir.game.haftkhabisvip.model.ClientIntent
import ir.game.haftkhabisvip.model.GameState
import ir.game.haftkhabisvip.model.PendingActionType
import ir.game.haftkhabisvip.model.Player
import ir.game.haftkhabisvip.model.Suit
import ir.game.haftkhabisvip.model.canPlay
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun GameTableScreen(
    state: GameState,
    myPlayer: Player,
    isHost: Boolean,
    disconnectedIds: List<String>,
    onSendIntent: (ClientIntent) -> Unit,
    onShowScores: () -> Unit,
    onSkipTurn: () -> Unit,
    onLeave: () -> Unit
) {
    val currentPlayer = state.players.getOrNull(state.currentTurnIndex)
    val isMyTurn = currentPlayer?.id == myPlayer.id
    val opponents = state.players.filter { it.id != myPlayer.id }
    val dots = remember {
        val r = Random(7)
        List(280) { Offset(r.nextFloat(), r.nextFloat()) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(feltBrush())
            .drawBehind {
                dots.forEach {
                    drawCircle(Color.White.copy(alpha = 0.025f), 1.2.dp.toPx(), Offset(it.x * size.width, it.y * size.height))
                }
                val inset = 6.dp.toPx()
                drawRoundRect(
                    Pal.Gold.copy(alpha = 0.14f),
                    Offset(inset, inset),
                    Size(size.width - 2 * inset, size.height - 2 * inset),
                    CornerRadius(28.dp.toPx(), 28.dp.toPx()),
                    style = Stroke(1.5.dp.toPx())
                )
            }
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 10.dp)) {
            // ---- سربرگ
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PillButton("خروج", onLeave, container = Color(0x33FFFFFF), content = Color.White)
                Box(
                    Modifier
                        .background(Color(0x55000000), RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        "دست ${state.currentRound} از ${state.totalRounds}   ${if (state.direction == -1) "↺" else "↻"}",
                        color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold
                    )
                }
                PillButton("جدول امتیاز", onShowScores)
            }

            Spacer(Modifier.height(6.dp))

            // ---- حریف‌ها
            val rows = opponents.chunked(if (opponents.size <= 4) 4 else 3)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                rows.forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { p ->
                            OpponentBadge(
                                p,
                                isTurn = currentPlayer?.id == p.id,
                                disconnected = p.id in disconnectedIds,
                                canCatch = state.catchTargetId == p.id,
                                onCatch = { onSendIntent(ClientIntent.CatchTakKard) }
                            )
                        }
                    }
                }
            }

            // ---- مرکز میز
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                DirectionRing(state.direction, Modifier.size(250.dp))
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (state.sevenChainPenalty > 0) {
                        val a = pulse(0.75f, 1f, 600)
                        Box(
                            Modifier
                                .graphicsLayer { alpha = a }
                                .background(Pal.Ruby, RoundedCornerShape(50))
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                "🔥 زنجیره هفت: ${state.sevenChainPenalty} کارت جریمه",
                                color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        DrawPile(
                            count = state.deckCount,
                            hint = isMyTurn && state.pendingAction == PendingActionType.NONE,
                            onClick = {
                                SoundEffects.playDrawCard()
                                onSendIntent(ClientIntent.DrawCard)
                            }
                        )
                        DiscardPile(state)
                        ActiveSuitBadge(state.activeSuit)
                    }

                    StatusBanner(state.statusMessage)

                    if (isMyTurn && state.pendingAction == PendingActionType.EIGHT_STREAK) {
                        PillButton("پایان نوبت ۸", { onSendIntent(ClientIntent.PassEightBonus) }, container = Color(0xFFFF8F00))
                    }
                    if (isHost && currentPlayer != null && currentPlayer.id in disconnectedIds) {
                        PillButton("رد کردن نوبتِ بازیکن قطع‌شده", onSkipTurn, container = Pal.Ruby, content = Color.White)
                    }
                }
            }

            // ---- نوار پایین
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val p = pulse(0.5f, 1f, 700)
                Box(
                    Modifier
                        .graphicsLayer { alpha = if (isMyTurn) p else 1f }
                        .background(if (isMyTurn) Color(0xFF1B5E20) else Color(0x55000000), RoundedCornerShape(50))
                        .border(1.5.dp, if (isMyTurn) Pal.Mint else Color(0x44FFFFFF), RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        if (isMyTurn) "نوبت شماست!" else "نوبت ${currentPlayer?.name ?: ""}",
                        color = if (isMyTurn) Pal.Mint else Color.LightGray,
                        fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 180.dp)
                    )
                }
                PillButton(
                    "اعلام تک کارت!",
                    { onSendIntent(ClientIntent.DeclareTakKard) },
                    enabled = myPlayer.hand.size <= 2 && !myPlayer.saidTakKard,
                    container = Color(0xFFD32F2F), content = Color.White
                )
            }

            // ---- دست خودم
            HandFan(
                cards = myPlayer.hand,
                enabled = isMyTurn,
                canPlay = { state.canPlay(it) },
                onPlay = { c -> onSendIntent(ClientIntent.PlayCard(c.id)) }
            )
        }

        if (isMyTurn && state.pendingAction == PendingActionType.CHOOSE_SUIT) {
            SuitSelectionDialog { onSendIntent(ClientIntent.SelectSuit(it)) }
        }
        if (isMyTurn && state.pendingAction == PendingActionType.GIVE_PENALTY_CARD) {
            GiveCardPenaltyDialog(
                myHand = myPlayer.hand,
                otherPlayers = opponents,
                onConfirm = { cardId, target -> onSendIntent(ClientIntent.GiveCardToPlayer(cardId, target)) }
            )
        }
    }
}

// ---------------------------------------------------------------- اجزای میز

@Composable
private fun DrawPile(count: Int, hint: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            CardBackView(width = 84.dp, modifier = Modifier.offset(x = 4.dp, y = 4.dp))
            CardBackView(width = 84.dp, modifier = Modifier.offset(x = 2.dp, y = 2.dp))
            CardBackView(width = 84.dp, glow = hint, label = "$count", onClick = onClick)
        }
        Spacer(Modifier.height(8.dp))
        Text("بانک", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
    }
}

@Composable
private fun DiscardPile(state: GameState) {
    val top = state.topCard
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(width = 100.dp, height = 140.dp)) {
        Box(
            Modifier
                .size(width = 84.dp, height = 119.dp)
                .graphicsLayer { rotationZ = -8f }
                .background(Pal.Ivory.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
        )
        if (top != null) {
            AnimatedContent(
                targetState = top,
                transitionSpec = {
                    (slideInVertically(tween(350)) { it / 2 } + fadeIn(tween(250)) + scaleIn(tween(300), initialScale = 1.25f)) togetherWith
                        fadeOut(tween(200))
                },
                label = "topCard"
            ) { c ->
                val tilt = ((c.id.hashCode() and 0xF) - 8) * 0.8f
                PlayingCardView(
                    card = c,
                    width = 90.dp,
                    modifier = Modifier.graphicsLayer { rotationZ = tilt }
                )
            }
        }
    }
}

@Composable
private fun ActiveSuitBadge(suit: Suit?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (suit != null && suit != Suit.JOKER) {
            AnimatedContent(
                targetState = suit,
                transitionSpec = {
                    (scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut())
                },
                label = "suit"
            ) { s ->
                Box(
                    Modifier
                        .size(48.dp)
                        .shadow(8.dp, CircleShape)
                        .background(Pal.Ivory, CircleShape)
                        .border(2.5.dp, Pal.Gold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    SuitIcon(s, 26.dp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("خال حکم", color = Pal.Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StatusBanner(text: String) {
    AnimatedContent(
        targetState = text,
        transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
        label = "status"
    ) { t ->
        Box(
            Modifier
                .widthIn(max = 330.dp)
                .background(Color(0x66000000), RoundedCornerShape(16.dp))
                .border(1.dp, Pal.Gold.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Text(
                t, color = Color(0xFFFFE082), fontWeight = FontWeight.Bold, fontSize = 13.sp,
                textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun DirectionRing(direction: Int, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "ring")
    val angle by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Restart),
        label = "ringAngle"
    )
    Canvas(
        modifier.graphicsLayer {
            rotationZ = angle
            scaleX = if (direction == -1) -1f else 1f
        }
    ) {
        val r = size.minDimension / 2f - 6.dp.toPx()
        val c = center
        val col = Pal.Gold.copy(alpha = 0.32f)
        for (k in 0 until 3) {
            val start = k * 120f + 10f
            drawArc(
                col, start, 72f, false,
                Offset(c.x - r, c.y - r), Size(2 * r, 2 * r),
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
            )
            val a = Math.toRadians((start + 72f).toDouble())
            val px = c.x + r * cos(a).toFloat()
            val py = c.y + r * sin(a).toFloat()
            val tx = -sin(a).toFloat()
            val ty = cos(a).toFloat()
            val nx = cos(a).toFloat()
            val ny = sin(a).toFloat()
            val head = Path().apply {
                moveTo(px + tx * 11.dp.toPx(), py + ty * 11.dp.toPx())
                lineTo(px - nx * 7.dp.toPx(), py - ny * 7.dp.toPx())
                lineTo(px + nx * 7.dp.toPx(), py + ny * 7.dp.toPx())
                close()
            }
            drawPath(head, col)
        }
    }
}

@Composable
private fun OpponentBadge(p: Player, isTurn: Boolean, disconnected: Boolean, canCatch: Boolean, onCatch: () -> Unit) {
    val a = pulse(0.4f, 1f, 750)
    val ring = if (isTurn) Pal.Gold.copy(alpha = a) else null
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.graphicsLayer { alpha = if (disconnected) 0.45f else 1f }
    ) {
        // بادبزن پشت کارت‌ها
        Box(Modifier.size(width = 76.dp, height = 40.dp), contentAlignment = Alignment.BottomCenter) {
            val shown = min(p.hand.size, 7)
            for (i in 0 until shown) {
                val rel = i - (shown - 1) / 2f
                CardBackView(
                    width = 22.dp,
                    modifier = Modifier
                        .offset(x = (rel * 8f).dp)
                        .graphicsLayer { rotationZ = rel * 8f }
                )
            }
        }
        Box(contentAlignment = Alignment.TopEnd) {
            Avatar(p.name, 46.dp, ring)
            Box(
                Modifier
                    .offset(x = 6.dp, y = (-4).dp)
                    .size(22.dp)
                    .background(Color(0xFF1A237E), CircleShape)
                    .border(1.5.dp, Pal.Gold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("${p.hand.size}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(
            p.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 80.dp)
        )
        Text(
            if (disconnected) "قطع شد" else "امتیاز \u200E${p.totalScore}",
            color = if (disconnected) Color(0xFFFF8A80) else Color(0xFFB0BEC5), fontSize = 10.sp
        )
        if (!disconnected && canCatch) {
            val cb = pulse(0.6f, 1f, 400)
            Box(
                Modifier
                    .graphicsLayer { alpha = cb }
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFFD32F2F))
                    .clickable { onCatch() }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("تک نگفت😁", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        } else if (!disconnected && p.saidTakKard) {
            val b = pulse(0.5f, 1f, 450)
            Text(
                "تک کارت!", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .graphicsLayer { alpha = b }
                    .background(Color(0xFFD32F2F), RoundedCornerShape(50))
                    .padding(horizontal = 8.dp, vertical = 1.dp)
            )
        }
    }
}
